### Hexlet tests and linter status:
[![Actions Status](https://github.com/ReYaNOW/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ReYaNOW/python-project-49/actions)
### CodeClimate tests and Maintainability status:
<a href="https://codeclimate.com/github/ReYaNOW/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f09f6f2f890183ba1102/maintainability" /></a>
Пример установки и работы команды brain-even программы\n
https://asciinema.org/a/551369 \n
Пример работы команды brain-calc программы \n
https://asciinema.org/a/551402 \n
Пример работы команды brain-gcd программы \n
https://asciinema.org/a/551517 \n
Пример работы команды brain-progression программы \n
https://asciinema.org/a/551531 \n
Пример работы команды brain-prime программы \n
https://asciinema.org/a/551539