# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.games.brain_calc:main',
                     'brain-even = brain_games.games.brain_even:main',
                     'brain-games = '
                     'brain_games.games.brain_games_greeting:main',
                     'brain-gcd = brain_games.games.brain_gcd:main',
                     'brain-prime = brain_games.games.brain_prime:main',
                     'brain-progression = '
                     'brain_games.games.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '«Игры разума» — набор из пяти консольных игр, построенных по принципу популярных мобильных приложений для прокачки мозга. Каждая игра задает вопросы, на которые нужно дать правильные ответы. После трех правильных ответов считается, что игра пройдена. Неправильные ответы завершают игру и предлагают пройти её заново.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ReYaNOW/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ReYaNOW/python-project-49/actions)\n### CodeClimate tests and Maintainability status:\n<a href="https://codeclimate.com/github/ReYaNOW/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f09f6f2f890183ba1102/maintainability" /></a>\nПример установки и работы команды brain-even программы\\n\nhttps://asciinema.org/a/551369 \\n\nПример работы команды brain-calc программы \\n\nhttps://asciinema.org/a/551402 \\n\nПример работы команды brain-gcd программы \\n\nhttps://asciinema.org/a/551517 \\n\nПример работы команды brain-progression программы \\n\nhttps://asciinema.org/a/551531 \\n\nПример работы команды brain-prime программы \\n\nhttps://asciinema.org/a/551539',
    'author': 'Sergey Kalye',
    'author_email': 'reyangood@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/ReYaNOW/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
