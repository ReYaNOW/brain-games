# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['brain_games', 'brain_games.games', 'brain_games.scripts']

package_data = \
{'': ['*']}

install_requires = \
['prompt>=0.4.1,<0.5.0']

entry_points = \
{'console_scripts': ['brain-calc = brain_games.games.brain_calc:main',
                     'brain-even = brain_games.games.brain_even:main',
                     'brain-games = '
                     'brain_games.games.brain_games_greeting:main',
                     'brain-gcd = brain_games.games.brain_gcd:main',
                     'brain-prime = brain_games.games.brain_prime:main',
                     'brain-progression = '
                     'brain_games.games.brain_progression:main']}

setup_kwargs = {
    'name': 'hexlet-code',
    'version': '0.1.0',
    'description': '«Игры разума» — набор из пяти консольных игр, построенных по принципу популярных мобильных приложений для прокачки мозга. Каждая игра задает вопросы, на которые нужно дать правильные ответы. После трех правильных ответов считается, что игра пройдена. Неправильные ответы завершают игру и предлагают пройти её заново.',
    'long_description': '### Hexlet tests and linter status:\n[![Actions Status](https://github.com/ReYaNOW/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/ReYaNOW/python-project-49/actions)\n### CodeClimate tests and Maintainability status:\n<a href="https://codeclimate.com/github/ReYaNOW/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/f09f6f2f890183ba1102/maintainability" /></a>  \n  \n  \nЭтот проект представляет собой игру - Игры разума  \n«Игры разума» — набор из пяти консольных игр, построенных по принципу популярных мобильных приложений для прокачки мозга. Каждая игра задает вопросы, на которые нужно дать правильные ответы. После трех правильных ответов считается, что игра пройдена. Неправильные ответы завершают игру и предлагают пройти ее заново. Игры:  \n\nКалькулятор. Арифметические выражения, которые необходимо вычислить.  \nПрогрессия. Поиск пропущенных чисел в последовательности чисел.  \nОпределение четного числа.  \nОпределение наибольшего общего делителя.  \nОпределение простого числа.  \n\nДля установки игры необходимо использовать команду ```python3 -m pip install --user dist/*.whl``` находясь в корневой директории проекта.  \nhttps://asciinema.org/a/551559  \n  \nДля запуска игры по определению четного числа необходимо использовать команду ```brain-even```\nhttps://asciinema.org/a/551560  \n  \nДля запуска игры «Калькулятор» необходимо использовать команду ```brain-calc```  \nhttps://asciinema.org/a/551578  \n  \nДля запуска игры по определение наибольшего общего делителя необходимо использовать команду ```brain-gcd```  \nhttps://asciinema.org/a/551517  \n  \nДля запуска игры «Прогрессия» необходимо использовать команду ```brain-progression```  \nhttps://asciinema.org/a/551531   \n  \nДля запуска игры по определение простого числа необходимо использовать команду ```brain-prime```  \nhttps://asciinema.org/a/551539  \n  \nМинимальные требования:  \nНаличие CLI  \nPython^3.10  \n',
    'author': 'Sergey Kalye',
    'author_email': 'reyangood@gmail.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/ReYaNOW/python-project-49',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'entry_points': entry_points,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
